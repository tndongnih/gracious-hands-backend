
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const dbPath = process.env.DB_PATH || './database/gracious_hands.db';
const db = new sqlite3.Database(dbPath);
async function initDB() {
  return new Promise((resolve) => {
    db.serialize(() => {
      db.run(`CREATE TABLE IF NOT EXISTS clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        facility_name TEXT NOT NULL,
        contact_person TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        phone TEXT,
        password_hash TEXT NOT NULL,
        service_type TEXT,
        pickup_address TEXT,
        delivery_address TEXT,
        role TEXT DEFAULT 'client',
        status TEXT DEFAULT 'active',
        notes TEXT,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_login DATETIME,
        must_change_password INTEGER DEFAULT 1
      )`);
      db.run(`CREATE TABLE IF NOT EXISTS requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_id INTEGER,
        facility_name TEXT,
        contact_person TEXT,
        email TEXT,
        phone TEXT,
        service_type TEXT,
        pickup_location TEXT,
        delivery_location TEXT,
        details TEXT,
        urgency TEXT DEFAULT 'scheduled',
        status TEXT DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`);
      db.run(`CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT DEFAULT 'admin',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`, () => {
        const adminEmail = process.env.ADMIN_EMAIL || 'admin@gracioushandstransit.com';
        const adminPass = process.env.ADMIN_PASSWORD || 'Admin123!';
        db.get('SELECT id FROM admins WHERE email = ?', [adminEmail], async (err, row) => {
          if (!row) {
            const hash = await bcrypt.hash(adminPass, 10);
            db.run('INSERT INTO admins (email, password_hash, role) VALUES (?, ?, ?)', [adminEmail, hash, 'admin'], () => {
              console.log('Default admin created: ' + adminEmail);
              createDemo();
            });
          } else { createDemo(); }
        });
        function createDemo() {
          db.get('SELECT id FROM clients WHERE email = ?', ['client@example.com'], async (err, row) => {
            if (!row) {
              const hash = await bcrypt.hash('Client123!', 10);
              db.run('INSERT INTO clients (facility_name, contact_person, email, phone, password_hash, service_type, role, status, must_change_password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                ['Demo Medical Center', 'John Doe', 'client@example.com', '240-755-7772', hash, 'STAT / Emergency Courier', 'client', 'active', 0],
                () => { console.log('Demo client created'); resolve(); });
            } else { resolve(); }
          });
        }
      });
    });
  });
}
module.exports = { db, initDB };
