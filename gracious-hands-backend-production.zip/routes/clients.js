
const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../database/db');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const router = express.Router();
router.use(authenticateToken, requireAdmin);
router.get('/', (req, res) => {
  db.all('SELECT id, facility_name, contact_person, email, phone, service_type, role, status, pickup_address, delivery_address, notes, created_at, last_login, must_change_password FROM clients ORDER BY created_at DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});
router.post('/', async (req, res) => {
  const { facility_name, contact_person, email, phone, password, service_type, pickup_address, delivery_address, role, notes } = req.body;
  if (!facility_name || !contact_person || !email || !password) return res.status(400).json({ error: 'Facility, contact, email and password required' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  try {
    const hash = await bcrypt.hash(password, 10);
    db.run('INSERT INTO clients (facility_name, contact_person, email, phone, password_hash, service_type, pickup_address, delivery_address, role, notes, created_by, status, must_change_password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "active", 1)',
      [facility_name, contact_person, email, phone, hash, service_type, pickup_address, delivery_address, role||'client', notes, req.user.id],
      function(err) {
        if (err) {
          if (err.message.includes('UNIQUE')) return res.status(409).json({ error: 'Email already exists' });
          return res.status(500).json({ error: err.message });
        }
        db.get('SELECT id, facility_name, contact_person, email, phone, service_type, role, status, created_at FROM clients WHERE id = ?', [this.lastID], (err, row) => {
          res.status(201).json({ success: true, message: 'Client account created', client: row, credentials: { email, temporary_password: password } });
        });
      });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});
router.post('/:id/reset-password', async (req, res) => {
  const { newPassword } = req.body;
  if (!newPassword || newPassword.length < 8) return res.status(400).json({ error: 'Min 8 chars' });
  const hash = await bcrypt.hash(newPassword, 10);
  db.run('UPDATE clients SET password_hash = ?, must_change_password = 1 WHERE id = ?', [hash, req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true, temporary_password: newPassword });
  });
});
router.post('/:id/toggle-status', (req, res) => {
  db.get('SELECT status FROM clients WHERE id = ?', [req.params.id], (err, row) => {
    if (!row) return res.status(404).json({ error: 'Not found' });
    const newStatus = row.status === 'active' ? 'deactivated' : 'active';
    db.run('UPDATE clients SET status = ? WHERE id = ?', [newStatus, req.params.id], () => res.json({ success: true, status: newStatus }));
  });
});
router.delete('/:id', (req, res) => {
  db.run('DELETE FROM clients WHERE id = ?', [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});
module.exports = router;
