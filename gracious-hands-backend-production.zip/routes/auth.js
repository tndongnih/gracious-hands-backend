
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../database/db');
const router = express.Router();
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
  const checkAdmin = () => new Promise((resolve, reject) => {
    db.get('SELECT * FROM admins WHERE email = ?', [email], async (err, admin) => {
      if (err) return reject(err);
      if (admin) {
        const valid = await bcrypt.compare(password, admin.password_hash);
        if (valid) {
          const token = jwt.sign({ id: admin.id, email: admin.email, role: 'admin', type: 'admin' }, process.env.JWT_SECRET, { expiresIn: '8h' });
          return resolve({ token, user: { id: admin.id, email: admin.email, role: 'admin', facility_name: 'Gracious Hands Transit - IT' } });
        }
      }
      resolve(null);
    });
  });
  const checkClient = () => new Promise((resolve, reject) => {
    db.get('SELECT * FROM clients WHERE email = ?', [email], async (err, client) => {
      if (err) return reject(err);
      if (client) {
        if (client.status !== 'active') return reject({ status: 403, message: 'Account deactivated. Contact IT' });
        const valid = await bcrypt.compare(password, client.password_hash);
        if (valid) {
          const token = jwt.sign({ id: client.id, email: client.email, role: client.role, facility_name: client.facility_name, type: 'client' }, process.env.JWT_SECRET, { expiresIn: '8h' });
          db.run('UPDATE clients SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [client.id]);
          return resolve({ token, user: { id: client.id, email: client.email, role: client.role, facility_name: client.facility_name, contact_person: client.contact_person, must_change_password: client.must_change_password } });
        }
      }
      resolve(null);
    });
  });
  try {
    let result = await checkClient();
    if (!result) result = await checkAdmin();
    if (!result) return res.status(401).json({ error: 'Invalid email or password' });
    res.json(result);
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    res.status(500).json({ error: 'Server error' });
  }
});
module.exports = router;
