
const express = require('express');
const { db } = require('../database/db');
const { authenticateToken } = require('../middleware/auth');
const router = express.Router();
router.use(authenticateToken);
router.post('/', (req, res) => {
  const { facility_name, contact_person, email, phone, service_type, pickup_location, delivery_location, details, urgency } = req.body;
  if (!service_type || !pickup_location || !delivery_location) return res.status(400).json({ error: 'Service, pickup and delivery required' });
  const clientId = req.user.type === 'client' ? req.user.id : (req.body.client_id || null);
  db.run('INSERT INTO requests (client_id, facility_name, contact_person, email, phone, service_type, pickup_location, delivery_location, details, urgency, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "pending")',
    [clientId, facility_name||req.user.facility_name, contact_person||req.user.contact_person, email||req.user.email, phone, service_type, pickup_location, delivery_location, details, urgency||'scheduled'],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      db.get('SELECT * FROM requests WHERE id = ?', [this.lastID], (err, row) => res.status(201).json({ success: true, request: row }));
    });
});
router.get('/', (req, res) => {
  if (req.user.role === 'admin' || req.user.type === 'admin') {
    db.all('SELECT * FROM requests ORDER BY created_at DESC', (err, rows) => res.json(rows));
  } else {
    db.all('SELECT * FROM requests WHERE client_id = ? ORDER BY created_at DESC', [req.user.id], (err, rows) => res.json(rows));
  }
});
module.exports = router;
