
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const rateLimit = require('express-rate-limit');
const { initDB } = require('./database/db');
const app = express();
const PORT = process.env.PORT || 3000;
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
const loginLimiter = rateLimit({ windowMs: 15*60*1000, max: 20, message: { error: 'Too many login attempts' } });
app.use('/api/auth', loginLimiter, require('./routes/auth'));
app.use('/api/admin/clients', require('./routes/clients'));
app.use('/api/requests', require('./routes/requests'));
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', company: 'Gracious Hands Transit LLC', phone: '240-755-7772', emails: ['info@gracioushandstransit.com','dispatch@gracioushandstransit.com'] });
});
app.get('*', (req, res) => { res.sendFile(path.join(__dirname, 'public', 'index.html')); });
initDB().then(() => {
  app.listen(PORT, () => {
    console.log('Gracious Hands Transit Backend running on http://localhost:'+PORT);
    console.log('Admin: '+(process.env.ADMIN_EMAIL||'admin@gracioushandstransit.com'));
  });
});
