# Gracious Hands Transit LLC - Node.js Backend\nPhone: 240-755-7772 | info@gracioushandstransit.com | dispatch@gracioushandstransit.com\n\n## Quick Start\n npm install\n npm start\n http://localhost:3000\nAdmin: admin@gracioushandstransit.com / Admin123!\n

## YOUR SECURE CREDENTIALS (Generated)
Admin Email: admin@gracioushandstransit.com
Admin Password: zoXSUM6#JY@HjKPv
JWT Secret: a5ca3c33e20d45afaeb65942d5a974987d7bad7863bb6c7aa62f94b315c760c9
Phone: 240-755-7772
Info: info@gracioushandstransit.com
Dispatch: dispatch@gracioushandstransit.com
