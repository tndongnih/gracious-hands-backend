
# Gracious Hands Transit LLC - Deployment Guide
Phone: 240-755-7772
Info: info@gracioushandstransit.com
Dispatch: dispatch@gracioushandstransit.com

## YOUR SECURE ADMIN CREDENTIALS
Admin Email: admin@gracioushandstransit.com
Admin Password: zoXSUM6#JY@HjKPv
JWT Secret: a5ca3c33e20d45afaeb65942d5a974987d7bad7863bb6c7aa62f94b315c760c9
Demo Client: client@example.com / Client123!

⚠️  CHANGE THE ADMIN PASSWORD AFTER FIRST LOGIN!

## 2-Step Deployment (Recommended)

### Step 1: Frontend on Namecheap (You already did this)
- Upload public/index.html to cPanel > File Manager > public_html
- Site: https://gracioushandstransit.com

### Step 2: Backend on Render.com (FREE - 2 minutes)

1. Go to github.com and create new repo "gracious-hands-backend"
2. Upload the entire backend folder to GitHub (drag & drop)
3. Go to render.com > Sign up > New Web Service > Connect GitHub repo
4. Settings:
   - Name: gracious-hands-transit
   - Build Command: npm install
   - Start Command: npm start
   - Environment: Node
   - Add Environment Variables:
     JWT_SECRET=a5ca3c33e20d45afaeb65942d5a974987d7bad7863bb6c7aa62f94b315c760c9
     ADMIN_EMAIL=admin@gracioushandstransit.com
     ADMIN_PASSWORD=zoXSUM6#JY@HjKPv
     NODE_ENV=production
5. Click Create Web Service - wait 2-3 mins - you get URL like https://gracious-hands-transit.onrender.com
6. Copy that URL

### Step 3: Connect Frontend to Backend

Edit public/index.html or your live site's JS:
Find: const API_BASE = '/api'
Replace with: const API_BASE = 'https://YOUR-RENDER-URL.onrender.com/api'

Or in cPanel File Manager, edit public_html/index.html:
Search for "API_BASE" and update.

Then your Client Login will use REAL database!

## How IT Creates Accounts (After Deployment)

1. Go to https://gracioushandstransit.com > Client Login > Admin/IT Login
2. Login: admin@gracioushandstransit.com / zoXSUM6#JY@HjKPv
3. Admin Dashboard > Create Account
4. Fill facility details, generate temp password, create
5. Copy credentials, email securely to client via info@gracioushandstransit.com

## Security

- Passwords are hashed with bcrypt (not plain text)
- JWT tokens expire in 8h
- Rate limiting on login (20 attempts per 15 min)
- SQLite database file should be backed up regularly
- Enable HTTPS in Namecheap cPanel > SSL/TLS

Support: info@gracioushandstransit.com | 240-755-7772
